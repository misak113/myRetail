/** Automatically generated file. DO NOT MODIFY */
package com.myRetail;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}