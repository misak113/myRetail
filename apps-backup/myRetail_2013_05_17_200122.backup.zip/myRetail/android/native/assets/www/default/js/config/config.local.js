
/* JavaScript content from js/config/config.local.js in folder common */

var configLocal = {
	serverUrl: 'http://localhost:1337',
	baseUrl: 'http://localhost:1337'
};