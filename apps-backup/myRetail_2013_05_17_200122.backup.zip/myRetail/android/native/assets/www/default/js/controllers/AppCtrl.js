
/* JavaScript content from js/controllers/AppCtrl.js in folder common */


function AppCtrl($scope) {

};