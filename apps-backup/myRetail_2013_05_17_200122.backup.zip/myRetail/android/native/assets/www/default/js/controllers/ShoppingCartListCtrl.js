
/* JavaScript content from js/controllers/ShoppingCartListCtrl.js in folder common */


function ShoppingCartListCtrl($scope) {

};