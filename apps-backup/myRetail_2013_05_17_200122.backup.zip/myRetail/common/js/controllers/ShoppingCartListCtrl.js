

function ShoppingCartListCtrl($scope) {

};