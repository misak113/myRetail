
var configLocal = {
	serverUrl: 'http://localhost:1337',
	baseUrl: 'http://localhost:1337'
};