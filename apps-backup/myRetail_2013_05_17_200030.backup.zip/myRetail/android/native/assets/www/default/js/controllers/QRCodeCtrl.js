
/* JavaScript content from js/controllers/QRCodeCtrl.js in folder common */

function QRCodeCtrl ($scope) {
	$scope.user = {card:{number:113569482}};
}