
/* JavaScript content from js/config/config.js in folder common */

var config = {
		serverUrl: 'http://localhost:1337'
};


myRetail.factory('config', function () {
	return config;
});